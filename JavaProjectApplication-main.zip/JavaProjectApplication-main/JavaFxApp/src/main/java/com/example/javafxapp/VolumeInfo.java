package com.example.javafxapp;

import java.util.List;

public class VolumeInfo {
    public String title;
    public List<String> authors;
    public String description;
    public ImageLinks imageLinks;
}

