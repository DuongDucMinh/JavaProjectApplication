package com.example.javafxapp;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class QRCodeGenerator {
    public static void generateQRCode(String id, int width, int height) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        String ip = "192.168.241.186";
        String ip2 = "localhost";
        String filePath = "local_html/qrcodes/" + id + ".png";
        String qrText = "http://" + ip + ":8000/books/" + id + ".html"; // URL trang sách

        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(qrText, BarcodeFormat.QR_CODE, width, height);
            Path path = Paths.get(filePath);
            MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
            //System.out.println("QR Code đã được tạo thành công!");
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
    }
}
