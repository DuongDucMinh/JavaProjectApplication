package com.example.javafxapp;

public class BookItem {
    public VolumeInfo volumeInfo;
}

