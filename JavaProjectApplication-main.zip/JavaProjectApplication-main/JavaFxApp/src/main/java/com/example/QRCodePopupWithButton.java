package com.example.javafxapp;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class QRCodePopupWithButton extends Application {

    // Hàm tạo QR Code
    public static BufferedImage generateQRCode(String text, int width, int height) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, width, height);
            return MatrixToImageWriter.toBufferedImage(bitMatrix);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void start(Stage primaryStage) {
        // Nút tạo QR Code
        Button generateQRButton = new Button("Tạo QR Code cho sách");

        // Dữ liệu sách ví dụ
        String bookData = "Tên sách: Lập trình Mẫu Giáo\nTác giả: Bùi Xuân Huấn\nNăm xuất bản: 2024";

        // Xử lý sự kiện khi nhấn nút
        generateQRButton.setOnAction(event -> {
            // Tạo QR Code
            BufferedImage qrCodeImage = generateQRCode(bookData, 300, 300);

            if (qrCodeImage != null) {
                try {
                    // Chuyển QR Code thành Image để hiển thị trong JavaFX
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    ImageIO.write(qrCodeImage, "png", outputStream);
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
                    Image qrCodeJavaFXImage = new Image(inputStream);

                    // Hiển thị QR Code trong pop-up
                    Stage popupStage = new Stage();
                    popupStage.initModality(Modality.APPLICATION_MODAL); // Đặt pop-up là modal
                    popupStage.setTitle("QR Code");

                    ImageView qrCodeView = new ImageView(qrCodeJavaFXImage);
                    qrCodeView.setFitWidth(300); // Kích thước hiển thị
                    qrCodeView.setFitHeight(300);
                    qrCodeView.setPreserveRatio(true);

                    VBox layout = new VBox(qrCodeView);
                    layout.setSpacing(10);

                    Scene popupScene = new Scene(layout, 350, 350);
                    popupStage.setScene(popupScene);
                    popupStage.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Giao diện chính
        VBox root = new VBox(generateQRButton);
        root.setSpacing(20);
        Scene scene = new Scene(root, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Ứng dụng quản lý thư viện");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}