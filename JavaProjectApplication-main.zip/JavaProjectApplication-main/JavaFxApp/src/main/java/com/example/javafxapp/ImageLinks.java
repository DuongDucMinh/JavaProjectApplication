package com.example.javafxapp;

public class ImageLinks {
    public String thumbnail;
}

