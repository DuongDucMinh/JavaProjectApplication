package com.example.javafxapp;

import java.sql.Date;

public class GetData {
    public static String path;
    public static String username;



    // SAVED DATA
    public static Book book;
    public static int borrowId;
    public static int bookId;
    public static Date returnDate;
    public static Date borrowDate;

    public static String title;
    public static String author;
    public static String category;
    public static String description;
    public static String pathImage;
}