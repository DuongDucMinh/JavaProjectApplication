import java.io.FileWriter;
import java.io.IOException;

public class HtmlGenerator {
    public static void generateHtml(String id, String title, String author, int year, String summary) {
        String cssPath = "styles.css"; // Đường dẫn tới file CSS
        String htmlContent = """
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>%s</title>
                    <link rel="stylesheet" href="%s">
                </head>
                <body>
                    <div class="book-container">
                        <h1 class="book-title">%s</h1>
                        <p class="book-author"><strong>Tác giả:</strong> %s</p>
                        <p class="book-year"><strong>Năm xuất bản:</strong> %d</p>
                        <p class="book-summary"><strong>Tóm tắt:</strong> %s</p>
                    </div>
                </body>
                </html>
                """.formatted(title, cssPath, title, author, year, summary);

        try (FileWriter writer = new FileWriter("local_html/books/" + id + ".html")) {
            writer.write(htmlContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
